const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');
const fg = require('fast-glob');

// Helper: is this a likely “real” class name?
function validClassName(cls) {
    // not empty
    if (!cls) return false;
    // cannot start with a digit
    if (/^[0-9]/.test(cls)) return false;
    // cannot be a unit or decimal value, e.g. "0.5rem", ".75", "3s"
    if (/^[0-9]*\.[0-9]+(rem|em|s|%)?$/.test(cls)) return false;
    // cannot contain illegal characters for class names (spaces etc are split already)
    // allow letters, digits, hyphen, underscore
    if (!/^[a-zA-Z_-][a-zA-Z0-9_-]*$/.test(cls)) return false;
    return true;
}

// Similar for IDs
function validIdName(id) {
    if (!id) return false;
    if (/^[0-9]/.test(id)) return false;
    // same noise check
    if (/^[0-9]*\.[0-9]+(rem|em|s|%)?$/.test(id)) return false;
    // avoid hex codes like fff or 000000
    if (/^[0-9A-Fa-f]{3,6}$/.test(id)) return false;
    // check valid characters
    if (!/^[a-zA-Z_-][a-zA-Z0-9_-]*$/.test(id)) return false;
    return true;
}

function extractSelectors(cssPath) {
    const css = fs.readFileSync(cssPath, 'utf-8');
    const classRegex = /\.([a-zA-Z0-9_-]+)\b/g;
    const idRegex = /#([a-zA-Z0-9_-]+)\b/g;

    const classes = new Set();
    const ids = new Set();

    let m;
    while ((m = classRegex.exec(css)) !== null) {
        const cls = m[1];
        if (validClassName(cls)) {
            classes.add(cls);
        }
    }
    while ((m = idRegex.exec(css)) !== null) {
        const id = m[1];
        if (validIdName(id)) {
            ids.add(id);
        }
    }
    return { classes, ids };
}

function checkUsageInHtml(filePath, classSelectors, idSelectors) {
    const content = fs.readFileSync(filePath, 'utf-8');
    const $ = cheerio.load(content);

    const used = {
        classes: new Set(),
        ids: new Set(),
    };

    // classes
    $('[class]').each((_, el) => {
        const attr = $(el).attr('class');
        if (!attr) return;
        const classList = attr.split(/\s+/);
        classList.forEach(cls => {
            if (classSelectors.has(cls)) {
                used.classes.add(cls);
            }
        });
    });

    // ids
    $('[id]').each((_, el) => {
        const id = $(el).attr('id');
        if (id && idSelectors.has(id)) {
            used.ids.add(id);
        }
    });

    return used;
}

function saveCSVReport(usageMap, outputPath) {
    let csv = 'selector,type,status,used_in_files\n';
    for (const [selector, files] of Object.entries(usageMap)) {
        const type = selector.startsWith('.') ? 'class' : 'id';
        const cleanSelector = selector.replace(/^(\.|#)/, '');
        const status = files.length ? 'used' : 'not_used';
        const usedFiles = files.join(';');
        // quote usedFiles in case it contains commas
        csv += `${cleanSelector},${type},${status},"${usedFiles}"\n`;
    }
    fs.writeFileSync(outputPath, csv, 'utf-8');
    console.log(`\n✅ Report saved as: ${outputPath}`);
}

async function run(cssPath, htmlDir) {
    const { classes, ids } = extractSelectors(cssPath);
    const usageMap = {};

    for (const cls of classes) usageMap['.' + cls] = [];
    for (const id of ids) usageMap['#' + id] = [];

    const htmlFiles = await fg(['**/*.html'], { cwd: htmlDir, absolute: true });

    for (const file of htmlFiles) {
        const used = checkUsageInHtml(file, classes, ids);

        for (const cls of used.classes) {
            usageMap['.' + cls].push(path.basename(file));
        }
        for (const id of used.ids) {
            usageMap['#' + id].push(path.basename(file));
        }
    }

    console.log('\n📊 CSS Selector Usage Report (Filtered):\n');
    for (const [selector, files] of Object.entries(usageMap)) {
        if (files.length > 0) {
            console.log(`✅ ${selector} → used in: ${files.join(', ')}`);
        } else {
            console.log(`❌ ${selector} → NOT USED`);
        }
    }

    // Save report
    saveCSVReport(usageMap, 'css-usage-report-filtered.csv');
}

// CLI args
const [,, cssPath, htmlDir] = process.argv;

if (!cssPath || !htmlDir) {
    console.error('❌ Usage: node css-usage-checker-filtered.js <path-to-css> <path-to-html-dir>');
    process.exit(1);
}

run(cssPath, htmlDir);

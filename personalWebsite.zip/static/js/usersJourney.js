document.addEventListener("DOMContentLoaded", function () {
    const topBarWrapper = document.querySelector('.top-bar-wrapper');
    document.body.style.paddingTop = topBarWrapper.offsetHeight + 'px';

    const totalPages = 11; // about, basketball, budget, home, matching, beyondTheCode, superbowl, wordle, ai_innovations_portal, htmlGems, chatBoard
    const currentPage = window.location.pathname;

    let visitedPages = JSON.parse(localStorage.getItem('visitedPages')) || [];

    if (!visitedPages.includes(currentPage)) {
        visitedPages.push(currentPage);
        localStorage.setItem('visitedPages', JSON.stringify(visitedPages));
    }

    const progress = (visitedPages.length / totalPages) * 100;
    const progressBar = document.getElementById('page-progress-bar');
    progressBar.style.width = progress + '%';
    progressBar.innerHTML = `User\'s Journey: ${Math.round(progress)}%`;

    if (progress === 100) {
        document.getElementById('reset-journey-btn').style.display = 'inline-block';
    }

    // Populate the dropdown
    const dropdown = document.getElementById('journey-dropdown');
    dropdown.innerHTML = ''; // Clear existing items

    function formatPageName(page) {
        if (page === '/') {
            return 'Home';
        }
        // Remove leading slash and .html extension
        let formatted = page.replace(/^\/|\.html$/g, '');
        // Insert space before capital letters for camelCase
        formatted = formatted.replace(/([A-Z])/g, ' $1');
        // Replace underscores and hyphens with spaces
        formatted = formatted.replace(/[_-]/g, ' ');
        // Capitalize the first letter of each word
        return formatted.replace(/\b\w/g, char => char.toUpperCase());
    }

    visitedPages.forEach(page => {
        const pageName = formatPageName(page);
        const link = document.createElement('a');
        link.href = page;
        link.textContent = pageName;
        dropdown.appendChild(link);
    });
});

function toggleDropdown() {
    document.getElementById('journey-dropdown').classList.toggle('show');
}

function resetJourney() {
    localStorage.removeItem('visitedPages');
    window.location.reload();
}